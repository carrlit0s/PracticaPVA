﻿-- Creamos la base de datos
CREATE DATABASE BurritoDB;
GO

-- Usamos la base de datos recién creada
USE BurritoDB;
GO

-- Tabla: Ingredientes
CREATE TABLE Ingredientes (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(100) NOT NULL,
    Precio INT NOT NULL -- Puedes cambiarlo a DECIMAL(10,2) si quieres precios decimales
);
GO

-- Tabla: Burritos
CREATE TABLE Burritos (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(100) NOT NULL,
    Tamaño NVARCHAR(50) NOT NULL,
    Precio INT NOT NULL -- Precio total del burrito
);
GO

-- Tabla intermedia: BurritoIngredientes
CREATE TABLE BurritoIngredientes (
    idBurrito INT NOT NULL,
    idIngrediente INT NOT NULL,

    CONSTRAINT PK_BurritoIngredientes PRIMARY KEY (idBurrito, idIngrediente),
    CONSTRAINT FK_Burrito FOREIGN KEY (idBurrito) REFERENCES Burritos(Id),
    CONSTRAINT FK_Ingrediente FOREIGN KEY (idIngrediente) REFERENCES Ingredientes(Id)
);
GO

-- Tabla: Usuarios
CREATE TABLE Usuarios (
    Id INT PRIMARY KEY IDENTITY(1,1),
    NombreUsuario NVARCHAR(50) NOT NULL UNIQUE,
    Contraseña NVARCHAR(100) NOT NULL,
    Rol NVARCHAR(20) NOT NULL -- Puede ser 'admin' o 'cliente'
);
GO
