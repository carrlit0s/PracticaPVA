﻿
--Ejecutar sentencia una a una, no todas a la vez

INSERT INTO Burritos (Nombre, Tamaño, Precio) VALUES
('Burrito Bacano', 'Grande', 370),
('Burrito Explosivo', 'Mediano', 375),
('Burrito Lamine Yamal', 'Grande', 355);

--

-- Burrito Bacano
INSERT INTO BurritoIngredientes (idBurrito, idIngrediente) VALUES
(1, 1), -- Lechuga
(1, 4), -- Tomate
(1, 6), -- Pollo
(1, 10), -- Guacamole
(1, 11); -- Alioli

-- Burrito Explosivo
INSERT INTO BurritoIngredientes (idBurrito, idIngrediente) VALUES
(2, 7),  -- Ternera
(2, 14), -- Jalapeños
(2, 3),  -- Cebolla
(2, 13), -- Salsa picante
(2, 2);  -- Pimiento

-- Burrito Lamine Yamal
INSERT INTO BurritoIngredientes (idBurrito, idIngrediente) VALUES
(3, 9),  -- Atún
(3, 1),  -- Lechuga
(3, 3),  -- Cebolla
(3, 12), -- Salsa de yogurt
(3, 5);  -- Judías

--Comprobar que se ha insertado todo correctamente
SELECT b.Nombre AS Burrito, i.Nombre AS Ingrediente
FROM BurritoIngredientes bi
JOIN Burritos b ON b.Id = bi.idBurrito
JOIN Ingredientes i ON i.Id = bi.idIngrediente
ORDER BY b.Nombre;
