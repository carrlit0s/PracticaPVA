﻿SET IDENTITY_INSERT Usuarios ON;

INSERT INTO Usuarios (Id, NombreUsuario, Contraseña, Rol) VALUES
(1, 'administrador', 'contraseña', 'admin'),
(2, 'juan perez', 'jp2010', 'cliente');

SET IDENTITY_INSERT Usuarios OFF;

SELECT * FROM Usuarios;